import os
import sys
sys.path.append(os.path.join(os.path.dirname('__file__'), '../'))

import torch
import numpy as np

from engine.solver import Trainer
from Utils.metric_utils import visualization
from Data.build_dataloader import build_dataloader
from Utils.io_utils import load_yaml_config, instantiate_from_config
from Models.interpretable_diffusion.model_utils import unnormalize_to_zero_to_one, cond_fn
from Models.interpretable_diffusion.ADClassifier import Model

class TrainerArgs:
    def __init__(self) -> None:
        self.config_path = 'Config/exampleConfig.yaml'
        self.gpu = 0
        self.save_dir = 'class_exp'
        os.makedirs(self.save_dir, exist_ok=True)

args =  TrainerArgs()
configs = load_yaml_config(args.config_path)
device = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')

dl_info = build_dataloader(configs, args)
model = instantiate_from_config(configs['model']).to(device)
classifier = instantiate_from_config(configs['classifier']).to(device)
trainer = Trainer(config=configs, args=args, model=model, dataloader=dl_info)



trainer.train()
GenSavePath = ""
torch.save(model,GenSavePath)

trainer.train_classfier(classifier)
ClassSavePath = ""
torch.save(classifier,ClassSavePath)
