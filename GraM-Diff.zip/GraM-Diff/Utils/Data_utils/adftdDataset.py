import os
import torch
import numpy as np
import random
from torch.utils.data import Dataset
from sklearn.preprocessing import MinMaxScaler
from Models.interpretable_diffusion.model_utils import normalize_to_neg_one_to_one, unnormalize_to_zero_to_one

def split_segments(data, segment_length, overlapping):
    """
    Splits time series data into overlapping segments.
    """
    T, C = data.shape
    if overlapping >= 1 or overlapping < 0:
        raise ValueError("Overlapping must be between 0 and 1")
    
    step = int(segment_length * (1 - overlapping))
    if step == 0: step = 1
    
    # Calculate number of segments
    num_segments = (T - segment_length) // step + 1
    if num_segments <= 0:
        return np.empty((0, segment_length, C))
        
    segments = []
    for i in range(num_segments):
        start = i * step
        end = start + segment_length
        segments.append(data[start:end, :])
    
    return np.array(segments)

def load_data_by_ids(data_path, label_path, ids, segment_length, overlapping):
    """
    Loads features for specific patient IDs and segments them.
    Returns:
        X: (N_segments, segment_length, feature_dim)
        y: (N_segments, 2) -> [class_label, patient_id]
    """
    # Load label file: [class, patient_id]
    all_labels = np.load(label_path)
    
    X_list = []
    y_list = []
    
    # Map patient_id to class label
    pid_to_label = {int(row[1]): int(row[0]) for row in all_labels}
    
    for pid in ids:
        pid = int(pid)
        file_name = f"feature_{pid:02d}.npy"
        file_path = os.path.join(data_path, file_name)
        
        if not os.path.exists(file_path):
            print(f"Warning: File {file_name} not found.")
            continue
            
        # Load data (T, C)
        data = np.load(file_path)
        
        # Segment data
        segments = split_segments(data, segment_length, overlapping)
        
        if len(segments) > 0:
            X_list.append(segments)
            
            # Create labels for these segments
            # Preserving [class, patient_id] structure
            label_val = pid_to_label.get(pid, -1)
            segment_labels = np.zeros((len(segments), 2))
            segment_labels[:, 0] = label_val
            segment_labels[:, 1] = pid
            y_list.append(segment_labels)

    if len(X_list) == 0:
        raise ValueError(f"No data loaded for IDs: {ids}")
        
    X = np.concatenate(X_list, axis=0)
    y = np.concatenate(y_list, axis=0)
    
    return X, y

def get_id_list_adftd(label_path, cross_val='fixed', seed=42, a=0.6, b=0.8, classify_choice='ad_vs_hc'):
    """
    Loads and splits subject IDs based on the strategy.
    """
    data_list = np.load(label_path)
    # data_list structure: [class, patient_id]
    
    all_ids = list(data_list[:, 1])
    hc_list = list(data_list[np.where(data_list[:, 0] == 0)][:, 1]) # Healthy
    ad_list = list(data_list[np.where(data_list[:, 0] == 1)][:, 1]) # AD
    ftd_list = list(data_list[np.where(data_list[:, 0] == 2)][:, 1]) # FTD
    
    if cross_val == 'fixed' or cross_val == 'mccv':
        if cross_val == 'fixed':
            random.seed(42)
        else:
            random.seed(seed)

        random.shuffle(hc_list)
        random.shuffle(ad_list)
        random.shuffle(ftd_list)

        # Standard Split
        train_ids = (hc_list[:int(a * len(hc_list))] + 
                     ad_list[:int(a * len(ad_list))] + 
                     ftd_list[:int(a * len(ftd_list))])
                     
        val_ids = (hc_list[int(a * len(hc_list)):int(b * len(hc_list))] +
                   ad_list[int(a * len(ad_list)):int(b * len(ad_list))] +
                   ftd_list[int(a * len(ftd_list)):int(b * len(ftd_list))])
                   
        test_ids = (hc_list[int(b * len(hc_list)):] + 
                    ad_list[int(b * len(ad_list)):] + 
                    ftd_list[int(b * len(ftd_list)):])

    elif cross_val == '5-fold':
        random.seed(42)
        random.shuffle(hc_list)
        random.shuffle(ad_list)
        random.shuffle(ftd_list)
        
        fold_size_hc = len(hc_list) / 5
        fold_size_ad = len(ad_list) / 5
        fold_size_ftd = len(ftd_list) / 5
        
        # Determine fold index from seed
        fold_idx = (seed - 41) % 5
        
        test_ids = (hc_list[int(fold_idx * fold_size_hc):int((fold_idx + 1) * fold_size_hc)] +
                    ad_list[int(fold_idx * fold_size_ad):int((fold_idx + 1) * fold_size_ad)] +
                    ftd_list[int(fold_idx * fold_size_ftd):int((fold_idx + 1) * fold_size_ftd)])
        
        val_idx = 0 if fold_idx == 4 else fold_idx + 1
        val_ids = (hc_list[int(val_idx * fold_size_hc):int((val_idx + 1) * fold_size_hc)] +
                   ad_list[int(val_idx * fold_size_ad):int((val_idx + 1) * fold_size_ad)] +
                   ftd_list[int(val_idx * fold_size_ftd):int((val_idx + 1) * fold_size_ftd)])
                   
        train_ids = [pid for pid in all_ids if pid not in test_ids and pid not in val_ids]

    elif cross_val == 'loso':
        # Leave-One-Subject-Out
        if classify_choice == 'ad_vs_hc':
             candidates = sorted(hc_list + ad_list)
        else:
             candidates = sorted(all_ids)
        
        test_idx = (seed - 41) % len(candidates)
        test_ids = [candidates[test_idx]]
        train_ids = [pid for pid in candidates if pid not in test_ids]
        
        # 10% validation from train
        random.seed(seed)
        random.shuffle(train_ids)
        split = int(0.9 * len(train_ids)) # 90% train, 10% val
        val_ids = train_ids[split:]
        train_ids = train_ids[:split]

    else:
        raise ValueError(f"Invalid cross_val: {cross_val}")

    return sorted(all_ids), sorted(train_ids), sorted(val_ids), sorted(test_ids)


class ADFTDDataset(Dataset):
    def __init__(
        self,
        data_root,
        window=128,
        overlapping=0.5,
        save2npy=True,
        neg_one_to_one=True,
        period='train',
        output_dir='./OUTPUT',
        # ADFTD specific args
        cross_val='fixed',
        classify_choice='ad_vs_hc',
        seed=42,
        split_ratios=(0.6, 0.8) # (a, b)
    ):
        super(ADFTDDataset, self).__init__()
        assert period in ['train', 'test', 'val'], 'period must be train, test or val.'
        
        self.data_root = data_root
        self.window = window
        self.period = period
        self.auto_norm = neg_one_to_one
        
        self.feature_path = os.path.join(data_root, 'Feature')
        self.label_path = os.path.join(data_root, 'Label/label.npy')
        
        # 1. Get IDs
        all_ids, train_ids, val_ids, test_ids = get_id_list_adftd(
            self.label_path, 
            cross_val=cross_val, 
            seed=seed, 
            a=split_ratios[0], 
            b=split_ratios[1],
            classify_choice=classify_choice
        )
        
        # 2. Select IDs based on period
        if period == 'train':
            self.ids = train_ids
        elif period == 'val':
            self.ids = val_ids
        elif period == 'test':
            self.ids = test_ids
        else:
            self.ids = all_ids

        print(f"[{period.upper()}] Loading ADFTD data for {len(self.ids)} patients...")
        print(f"IDs: {self.ids}")

        # 3. Load Data
        self.X, self.y = load_data_by_ids(
            self.feature_path, 
            self.label_path, 
            self.ids, 
            segment_length=window, 
            overlapping=overlapping
        )
        
        # 4. Filter/Modify labels based on task
        if classify_choice == 'ad_vs_hc': # 1 vs 0 (Delete FTD=2)
            mask = (self.y[:, 0] < 2)
            self.X = self.X[mask]
            self.y = self.y[mask]
            print(f"Filtered FTD subjects. Remaining samples: {len(self.y)}")
        elif classify_choice == 'ad_vs_nonad': # AD=1, Others=0
            self.y[:, 0] = np.where(self.y[:, 0] > 1, 0, self.y[:, 0])
        elif classify_choice == 'hc_vs_abnormal': # HC=0, Others=1
            self.y[:, 0] = np.where(self.y[:, 0] > 1, 1, self.y[:, 0])
        
        # 5. Normalize
        # Consistent with DiffClone: Fit scaler on loaded data (or pass scaler if strict)
        # Note: Ideally, fit on training and transform test. Here we fit on current batch for simplicity 
        # as per existing eegAdFormerDataset, but for strictness you might want to separate this.
        self.scaler = MinMaxScaler()
        # Flatten for scaling: (N*L, C)
        N, L, C = self.X.shape
        self.X_flat = self.X.reshape(-1, C)
        self.scaler.fit(self.X_flat)
        self.X_flat = self.scaler.transform(self.X_flat)
        
        if self.auto_norm:
            self.X_flat = normalize_to_neg_one_to_one(self.X_flat)
            
        self.samples = self.X_flat.reshape(N, L, C)
        
        # Prepare labels for simple access (just class label)
        self.labels = self.y[:, 0].astype(np.int64)
        
        self.sample_num = self.samples.shape[0]
        self.var_num = C
        self.len = N

    def __getitem__(self, ind):
        x = self.samples[ind, :, :]
        # Return (x, y) if test or val (for classifier), else just x (for diffusion)
        if self.period in ['test', 'val']:
            y = self.labels[ind]
            return torch.from_numpy(x).float(), torch.tensor(y)
        
        return torch.from_numpy(x).float()

    def __len__(self):
        return self.sample_num

    def unnormalize(self, x):
        # x: (N, L, C)
        N, L, C = x.shape
        x_flat = x.reshape(-1, C)
        if self.auto_norm:
            x_flat = unnormalize_to_zero_to_one(x_flat)
        x_inv = self.scaler.inverse_transform(x_flat)
        return x_inv.reshape(N, L, C)
    
    def shift_period(self, period):
        # This is a hack used in solver.py to switch __getitem__ behavior
        # It does NOT reload data.
        self.period = period