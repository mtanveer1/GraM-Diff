import os
import sys

import torch
import numpy as np

from engine.solver import Trainer
from Utils.metric_utils import visualization
from Data.build_dataloader import build_dataloader
from Utils.io_utils import load_yaml_config, instantiate_from_config
from Models.interpretable_diffusion.model_utils import unnormalize_to_zero_to_one, cond_fn
from Models.interpretable_diffusion.ADClassifier import Model

class Args_Example:
    def __init__(self) -> None:
        self.config_path = 'Config/exampleConfig.yaml'
        self.gpu = 0
        self.save_dir = 'class_exp'
        os.makedirs(self.save_dir, exist_ok=True)

args =  Args_Example()
configs = load_yaml_config(args.config_path)
device = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')

dl_info = build_dataloader(configs, args)
model = instantiate_from_config(configs['model']).to(device)
classifier = instantiate_from_config(configs['classifier']).to(device)
model = (torch.load("Saved/Gen.pth",weights_only=False))
classifier = (torch.load("Saved/Classifier.pth",weights_only=False))
trainer = Trainer(config=configs, args=args, model=model, dataloader=dl_info)
dataset = dl_info['dataset']
seq_length, feature_dim = dataset.window, dataset.var_num

model_kwargs = {}
model_kwargs['classifier'] = classifier
model_kwargs['classifier_scale'] = 0.1

seq_length, feature_dim

ori_data_0 = dataset.normalize(dataset.data_0)
origDataSave = ""
fakeDataSave = ""
np.save(origDataSave,ori_data_0)

fake_data_0 = []


model_kwargs['y'] = torch.zeros((100, )).long().to(device)
fake_data = trainer.sample(num=4500, size_every=100, shape=[seq_length, feature_dim], 
                         model_kwargs=model_kwargs, cond_fn=cond_fn)
fake_data_0.append(fake_data)

fake_data_0 = np.concat(fake_data_0)
np.save(fakeDataSave,fake_data_0)
if dataset.auto_norm:
    ori_data_0 = unnormalize_to_zero_to_one(ori_data_0)
    fake_data_0 = unnormalize_to_zero_to_one(fake_data_0)

ori_data_1 = dataset.normalize(dataset.data_1)
origDataSave = "";
fakeDataSave = "";
np.save(origDataSave,ori_data_1)
model_kwargs['y'] = torch.ones((100, )).long().to(device)

fake_data_1 = trainer.sample(4500, size_every=100, shape=[seq_length, feature_dim], 
                             model_kwargs=model_kwargs, cond_fn=cond_fn)
np.save(fakeDataSave,fake_data_1)
if dataset.auto_norm:
    ori_data_1 = unnormalize_to_zero_to_one(ori_data_1)
    fake_data_1 = unnormalize_to_zero_to_one(fake_data_1)