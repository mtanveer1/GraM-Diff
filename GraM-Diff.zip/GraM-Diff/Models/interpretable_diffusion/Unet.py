import torch
from torch import nn
from einops import rearrange
import torch.nn.functional as F
from Models.interpretable_diffusion.UnetComps import SinusoidalPositionEmbeddings, ResnetBlock1D
from Models.interpretable_diffusion.transformer import Transformer  # ADD THIS IMPORT
from torch_geometric.nn import GCNConv

class UNet1D(nn.Module):
    def __init__(
        self,
        feature_size,
        seq_len,  # NEW: required to calculate bottleneck sequence length for Transformer
        d_model=64,
        dim_mults=(1, 2, 4, 8),
        use_gnn=True,
        gnn_hidden_dim=None,
        gnn_layers=2,
        # Transformer args
        trans_enc_layers=2, # Reduced defaults for bottleneck efficiency
        trans_dec_layers=2,
        trans_heads=8
    ):
        super().__init__()
        
        self.feature_size = feature_size
        self.use_gnn = use_gnn
        
        # NEW: GNN preprocessing layers
        if self.use_gnn:
            self.gnn_hidden_dim = gnn_hidden_dim if gnn_hidden_dim is not None else feature_size
            self.gnn_layers = nn.ModuleList()
            
            # First GNN layer: feature_size -> gnn_hidden_dim
            self.gnn_layers.append(GCNConv(feature_size, self.gnn_hidden_dim))
            
            # Additional GNN layers: gnn_hidden_dim -> gnn_hidden_dim
            for _ in range(gnn_layers - 1):
                self.gnn_layers.append(GCNConv(self.gnn_hidden_dim, self.gnn_hidden_dim))
            
            # Activation and normalization for GNN
            self.gnn_activation = nn.GELU()
            self.gnn_norm = nn.LayerNorm(self.gnn_hidden_dim)
            
            # Project GNN output back to feature_size for UNet compatibility
            self.gnn_project = nn.Linear(self.gnn_hidden_dim, feature_size)
        
        time_dim = d_model * 4
        self.time_mlp = nn.Sequential(
            SinusoidalPositionEmbeddings(d_model),
            nn.Linear(d_model, time_dim),
            nn.GELU(),
            nn.Linear(time_dim, time_dim),
        )

        # Down-sampling path (Encoder)
        self.down_blocks = nn.ModuleList()
        dims = [feature_size, *[d_model * m for m in dim_mults]]
        in_out = list(zip(dims[:-1], dims[1:]))
        
        # Calculate number of downsampling steps
        num_downsamples = 0
        
        for ind, (in_c, out_c) in enumerate(in_out):
            is_last = ind >= (len(in_out) - 1)
            if not is_last:
                num_downsamples += 1
            
            self.down_blocks.append(
                nn.ModuleList(
                    [
                        ResnetBlock1D(in_c, out_c, time_emb_dim=time_dim),
                        ResnetBlock1D(out_c, out_c, time_emb_dim=time_dim),
                        nn.Conv1d(out_c, out_c, kernel_size=4, stride=2, padding=1)
                        if not is_last
                        else nn.Identity(),
                    ]
                )
            )

        # Bottleneck: Replace ResnetBlocks with Diffusion TS (Transformer)
        mid_dim = dims[-1]
        
        # Calculate bottleneck sequence length
        # Assuming stride 2 for each downsampling layer
        self.bottleneck_len = seq_len // (2 ** num_downsamples)
        
        # Transformer Parameters
        # n_feat: Feature dimension (channels in UNet bottleneck)
        # n_channel: Sequence length (time steps in UNet bottleneck) for TrendBlock
        # n_embd: Internal embedding dim of Transformer (matching mid_dim to avoid resizing)
        self.mid_transformer = Transformer(
            n_feat=mid_dim,
            n_channel=self.bottleneck_len,
            n_layer_enc=trans_enc_layers,
            n_layer_dec=trans_dec_layers,
            n_embd=mid_dim,
            n_heads=trans_heads,
            attn_pdrop=0.1,
            resid_pdrop=0.1,
            mlp_hidden_times=4,
            max_len=self.bottleneck_len # Ensure max_len covers the bottleneck length
        )

        # Up-sampling path (Decoder)
        self.up_blocks = nn.ModuleList()
        in_out_rev = list(reversed(in_out[1:]))

        for ind, (out_c, in_c) in enumerate(in_out_rev):
            is_last = ind >= (len(in_out_rev) - 1)
            self.up_blocks.append(
                nn.ModuleList(
                    [
                        nn.ConvTranspose1d(in_c, out_c, kernel_size=4, stride=2, padding=1),
                        ResnetBlock1D(out_c * 2, out_c, time_emb_dim=time_dim),
                        ResnetBlock1D(out_c, out_c, time_emb_dim=time_dim),
                    ]
                )
            )

        # Final output layer - outputs 2 * feature_size channels
        self.final_conv = nn.Conv1d(d_model, 2 * feature_size, 1)

    def forward(self, x, t, edge_index=None, padding_masks=None):
        # x input shape: (B, T, C) = (Batch, Seq_Len, feature_size)
        
        # NEW: Apply GNN preprocessing if enabled
        if self.use_gnn and edge_index is not None:
            B, T, C = x.shape
            
            # Reshape for GNN: (B, T, C) -> (B*T, C)
            x_flat = x.reshape(B * T, C)
            
            # Apply GNN layers
            for i, gnn_layer in enumerate(self.gnn_layers):
                x_flat = gnn_layer(x_flat, edge_index)
                if i < len(self.gnn_layers) - 1:  # Don't apply after last layer
                    x_flat = self.gnn_activation(x_flat)
            
            # Normalize and project back
            x_flat = self.gnn_norm(x_flat)
            x_flat = self.gnn_project(x_flat)
            
            # Reshape back: (B*T, C) -> (B, T, C)
            x = x_flat.reshape(B, T, C)
        
        # Conv1D expects: (B, C, T)
        x = x.permute(0, 2, 1)

        # Get time embedding for ResNet blocks
        time_emb = self.time_mlp(t)
        
        # Down-path
        skips = []
        for block1, block2, downsample in self.down_blocks:
            x = block1(x, time_emb)
            skips.append(x)
            
            x = block2(x, time_emb)
            skips.append(x)
            
            x = downsample(x)

        # Bottleneck with Diffusion TS Transformer
        # x shape at bottleneck: (B, mid_dim, T_bottleneck)
        
        # Transformer expects (B, T, C), so we permute
        x_trans = x.permute(0, 2, 1) 
        
        # Forward pass through Transformer
        # Returns: trend, season_error
        # We sum them to get the refined representation
        trend, season = self.mid_transformer(x_trans, t)
        x_trans_out = trend + season
        
        # Permute back to (B, C, T) for UNet up-path
        x = x_trans_out.permute(0, 2, 1)

        # Discard the last two skips from deepest level (standard UNet logic)
        _ = skips.pop()
        _ = skips.pop()

        # Up-path
        for upsample, block1, block2 in self.up_blocks:
            x = upsample(x)
            
            # Pop skip 2 (from after block2 on down-path)
            skip = skips.pop()
            
            # Robust resizing
            if x.shape[2] != skip.shape[2]:
                x = F.interpolate(x, size=skip.shape[2], mode='linear', align_corners=False)

            # Concatenate skip connection
            x = torch.cat((x, skip), dim=1)
            x = block1(x, time_emb)

            # Pop skip 1 (from before block2 on down-path)
            skip = skips.pop()
            
            # Robust resizing
            if x.shape[2] != skip.shape[2]:
                x = F.interpolate(x, size=skip.shape[2], mode='linear', align_corners=False)
            
            # Add skip (not concatenate for block2)
            x = x + skip
            x = block2(x, time_emb)

        # Final output
        out = self.final_conv(x)
        
        # Split into two components
        component1, component2 = out.chunk(2, dim=1)
        
        # Permute back to (B, T, C)
        return component1.permute(0, 2, 1), component2.permute(0, 2, 1)